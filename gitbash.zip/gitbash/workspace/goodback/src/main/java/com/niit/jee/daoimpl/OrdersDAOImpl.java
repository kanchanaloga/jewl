package com.niit.jee.daoimpl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.niit.jee.dao.OrdersDAO;
import com.niit.jee.model.Orders;

@Repository
public class OrdersDAOImpl implements OrdersDAO {

	public void persist(Orders o) {
		// TODO Auto-generated method stub

	}

	public void update(Orders o) {
		// TODO Auto-generated method stub

	}

	public Orders findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(Orders o) {
		// TODO Auto-generated method stub

	}

	public List<Orders> getAllOrders() {
		// TODO Auto-generated method stub
		return null;
	}

	public void deleteAll() {
		// TODO Auto-generated method stub

	}

}
